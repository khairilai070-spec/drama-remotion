# Drama Remotion 9:16

1. `npm install`
2. `npm run dev`  → pratinjau di browser (Remotion Studio)
3. `npm run render` → hasil di `out/episode-1.mp4` (1080x1920, 30 fps)

## Mengubah isi
- Naskah, durasi, gerak kamera, lokasi: `src/scenes.ts`
- Gambar latar: taruh file di folder `public/`, lalu isi `image: "nama-file.jpg"` pada adegan
- Musik: taruh `bgm.mp3` di `public/` dan aktifkan baris `<Audio>` di `src/Drama.tsx`
