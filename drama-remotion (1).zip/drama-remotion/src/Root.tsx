import React from "react";
import { Composition } from "remotion";
import { Drama, totalFrames } from "./Drama";

const FPS = 30;

export const Root: React.FC = () => {
  return (
    <Composition
      id="Drama"
      component={Drama}
      width={1080}
      height={1920}
      fps={FPS}
      durationInFrames={totalFrames(FPS)}
    />
  );
};
