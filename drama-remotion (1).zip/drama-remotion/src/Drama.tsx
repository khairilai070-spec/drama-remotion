import React from "react";
import {
  AbsoluteFill,
  Img,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { CHARACTER_COLORS, EPISODE, SCENES, Scene as SceneType } from "./scenes";
import { body, display } from "./fonts";

const FADE = 8; // frame fade in/out antar adegan

export const totalFrames = (fps: number) =>
  Math.round(
    (EPISODE.titleSeconds + SCENES.reduce((s, sc) => s + sc.seconds, 0)) * fps
  );

// ---------- Kartu judul ----------
const TitleCard: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const pop = spring({ frame, fps, config: { damping: 200 } });
  const out = interpolate(frame, [durationInFrames - 10, durationInFrames], [1, 0], {
    extrapolateLeft: "clamp",
  });
  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(circle at 50% 40%, #4a0e1c 0%, #0a0305 75%)",
        justifyContent: "center",
        alignItems: "center",
        padding: 90,
        opacity: out,
      }}
    >
      <div
        style={{
          fontFamily: body,
          fontWeight: 500,
          fontSize: 38,
          color: "#E8B04B",
          letterSpacing: 6,
          opacity: pop,
        }}
      >
        Episode {EPISODE.number}
      </div>
      <div
        style={{
          fontFamily: display,
          fontWeight: 700,
          fontSize: 116,
          lineHeight: 1.1,
          color: "#F7EFE3",
          textAlign: "center",
          marginTop: 36,
          transform: `translateY(${(1 - pop) * 40}px)`,
          opacity: pop,
        }}
      >
        {EPISODE.title}
      </div>
    </AbsoluteFill>
  );
};

// ---------- Satu adegan ----------
const SceneView: React.FC<{ scene: SceneType }> = ({ scene }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const t = frame / durationInFrames;

  // Gerak kamera
  let scale = 1.08;
  let tx = 0;
  if (scene.camera === "zoom-in") scale = interpolate(t, [0, 1], [1.05, 1.28]);
  if (scene.camera === "zoom-out") scale = interpolate(t, [0, 1], [1.3, 1.05]);
  if (scene.camera === "pan-left") {
    scale = 1.2;
    tx = interpolate(t, [0, 1], [60, -60]);
  }
  if (scene.camera === "pan-right") {
    scale = 1.2;
    tx = interpolate(t, [0, 1], [-60, 60]);
  }
  const shakeX = scene.shake ? Math.sin(frame * 1.7) * 5 : 0;
  const shakeY = scene.shake ? Math.cos(frame * 2.3) * 5 : 0;

  // Fade antar adegan
  const opacity = interpolate(
    frame,
    [0, FADE, durationInFrames - FADE, durationInFrames],
    [0, 1, 1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );

  // Dialog dibagi rata
  const perLine = durationInFrames / scene.lines.length;
  const idx = Math.min(scene.lines.length - 1, Math.floor(frame / perLine));
  const line = scene.lines[idx];
  const lineFrame = frame - idx * perLine;
  const pop = spring({ frame: lineFrame, fps, config: { damping: 14, stiffness: 160 } });
  const color = CHARACTER_COLORS[line.speaker] ?? "#F7EFE3";

  return (
    <AbsoluteFill style={{ opacity, backgroundColor: "#000" }}>
      {/* Latar + kamera */}
      <AbsoluteFill
        style={{
          transform: `translate(${tx + shakeX}px, ${shakeY}px) scale(${scale})`,
          background: `linear-gradient(170deg, ${scene.bg[0]}, ${scene.bg[1]})`,
        }}
      >
        {scene.image ? (
          <Img
            src={staticFile(scene.image)}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        ) : null}
      </AbsoluteFill>

      {/* Vignette sinematik */}
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(0,0,0,0.75) 100%)",
        }}
      />
      {/* Letterbox atas-bawah untuk area teks */}
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(to bottom, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0) 18%, rgba(0,0,0,0) 62%, rgba(0,0,0,0.8) 100%)",
        }}
      />

      {/* Lokasi */}
      <div
        style={{
          position: "absolute",
          top: 110,
          left: 70,
          right: 70,
          fontFamily: body,
          fontWeight: 500,
          fontSize: 36,
          color: "#F7EFE3",
          opacity: 0.9,
        }}
      >
        {scene.location}
      </div>

      {/* Subtitle */}
      <div
        style={{
          position: "absolute",
          left: 60,
          right: 60,
          bottom: 330,
          display: "flex",
          flexDirection: "column",
          alignItems: line.speaker ? "flex-start" : "center",
          transform: `scale(${0.92 + 0.08 * pop})`,
          opacity: pop,
        }}
      >
        {line.speaker ? (
          <div
            style={{
              fontFamily: body,
              fontWeight: 700,
              fontSize: 38,
              color: "#14080b",
              background: color,
              padding: "8px 24px",
              borderRadius: 10,
              marginBottom: 18,
            }}
          >
            {line.speaker}
          </div>
        ) : null}
        <div
          style={{
            fontFamily: line.speaker ? body : display,
            fontWeight: line.speaker ? 700 : 700,
            fontStyle: line.speaker ? "normal" : "italic",
            fontSize: line.speaker ? 62 : 56,
            lineHeight: 1.25,
            color: "#FFFFFF",
            textAlign: line.speaker ? "left" : "center",
            textShadow: "0 4px 18px rgba(0,0,0,0.9)",
          }}
        >
          {line.text}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// ---------- Episode ----------
export const Drama: React.FC = () => {
  const { fps } = useVideoConfig();
  let cursor = 0;
  const titleFrames = EPISODE.titleSeconds * fps;
  cursor += titleFrames;

  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      <Sequence from={0} durationInFrames={titleFrames}>
        <TitleCard />
      </Sequence>
      {SCENES.map((scene) => {
        const from = cursor;
        const dur = Math.round(scene.seconds * fps);
        cursor += dur;
        return (
          <Sequence key={scene.id} from={from} durationInFrames={dur}>
            <SceneView scene={scene} />
          </Sequence>
        );
      })}
      {/* Musik latar (opsional): taruh bgm.mp3 di /public lalu aktifkan:
          <Audio src={staticFile("bgm.mp3")} volume={0.35} /> */}
    </AbsoluteFill>
  );
};
