// ============================================================
// EDIT FILE INI SAJA untuk mengganti naskah, adegan, dan gambar.
// Semua teks di bawah adalah contoh pembuka — ganti dengan naskahmu.
// ============================================================

export type Camera = "zoom-in" | "zoom-out" | "pan-left" | "pan-right" | "static";

export type Line = {
  speaker: string; // nama tokoh; kosongkan ("") untuk narasi
  text: string;
};

export type Scene = {
  id: string;
  location: string; // teks lokasi di kiri atas
  seconds: number; // durasi adegan
  camera: Camera; // gerak kamera
  bg: [string, string]; // gradasi cadangan jika tidak ada gambar
  image?: string; // nama file di folder /public, mis. "ruang-vip.jpg"
  shake?: boolean; // getar kamera untuk momen tegang
  lines: Line[]; // dialog, dibagi rata sepanjang durasi adegan
};

export const EPISODE = {
  number: 1,
  title: "Pengkhianatan di Ruang VIP",
  titleSeconds: 3,
};

// Warna per tokoh (chip nama di subtitle)
export const CHARACTER_COLORS: Record<string, string> = {
  Laras: "#E8B04B",
  Dion: "#7FB3D5",
  Bella: "#E07A8B",
  "Bu Sandra": "#A9CBA4",
  Kurir: "#C9C9C9",
};

export const SCENES: Scene[] = [
  {
    id: "lobi",
    location: "Restoran Rasa Ningrat — Lobi",
    seconds: 6,
    camera: "zoom-in",
    bg: ["#3b0f1a", "#12060a"],
    lines: [
      { speaker: "", text: "Malam itu, Laras datang membawa kejutan." },
      { speaker: "Laras", text: "Dion bilang dia lembur. Biar aku antar makan malam." },
    ],
  },
  {
    id: "koridor",
    location: "Koridor Ruang VIP",
    seconds: 6,
    camera: "pan-right",
    bg: ["#2a1a0d", "#0d0704"],
    lines: [
      { speaker: "Bu Sandra", text: "Mbak Laras? Ruang VIP sedang dipakai tamu penting." },
      { speaker: "Laras", text: "Saya cuma sebentar, Bu." },
    ],
  },
  {
    id: "pintu",
    location: "Depan Pintu VIP",
    seconds: 5,
    camera: "zoom-in",
    shake: true,
    bg: ["#1a1a2e", "#07070f"],
    lines: [
      { speaker: "", text: "Tawa seorang perempuan terdengar dari balik pintu." },
      { speaker: "Laras", text: "Itu... suara Bella?" },
    ],
  },
  {
    id: "ruang-vip",
    location: "Ruang VIP",
    seconds: 8,
    camera: "zoom-out",
    shake: true,
    bg: ["#4a0e1c", "#10050a"],
    lines: [
      { speaker: "Dion", text: "Laras?! Ini... bukan seperti yang kamu lihat." },
      { speaker: "Bella", text: "Santai, Yon. Biar dia tahu sekalian." },
      { speaker: "Laras", text: "Tiga tahun, Dion. Tiga tahun aku percaya sama kamu." },
    ],
  },
  {
    id: "bu-sandra",
    location: "Ruang VIP",
    seconds: 5,
    camera: "pan-left",
    bg: ["#26202e", "#0a080d"],
    lines: [
      { speaker: "Bu Sandra", text: "Cukup. Semua keluar dari ruangan ini. Sekarang." },
    ],
  },
  {
    id: "pintu-depan",
    location: "Pintu Masuk Restoran",
    seconds: 6,
    camera: "zoom-in",
    bg: ["#102a33", "#05090b"],
    lines: [
      { speaker: "", text: "Di saat yang sama, seorang pria berjaket kurir melangkah masuk." },
      { speaker: "Kurir", text: "Permisi. Paket untuk Ibu Laras Ayu Ningrat." },
    ],
  },
];
