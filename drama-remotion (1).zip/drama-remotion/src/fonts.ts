import { loadFont as loadDisplay } from "@remotion/google-fonts/PlayfairDisplay";
import { loadFont as loadBody } from "@remotion/google-fonts/Inter";

export const display = loadDisplay("normal", { weights: ["700"] }).fontFamily;
export const body = loadBody("normal", { weights: ["500", "700"] }).fontFamily;
