# folder untuk gambar latar & audio
